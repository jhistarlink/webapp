from django.http import HttpResponse,HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse

from django.template import loader
from .models import Event, Participant

# Create your views here.

def index(request):
    return render(request, "index.html", {
        "events": Event.objects.all()
    })

def event(request, event_id):
    event = Event.objects.get(pk=event_id)
    return render(request, "event.html", {
        "event": event,
        "participants": event.participants.all(),
        "non_participants": Participant.objects.exclude(events=event).all()
    })

def book(request, event_id):
    if request.method == "POST":
        event = Event.objects.get(pk=event_id)
        participant = Participant.objects.get(pk=int(request.POST["participant"]))    
        participant.events.add(event)
        return HttpResponseRedirect(reverse("event", args=(event.id,)))