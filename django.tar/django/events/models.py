from django.db import models

# Create your models here.

class Event(models.Model):
    name = models.CharField(max_length=50)
    date = models.DateField()

class Participant(models.Model):
    first = models.CharField(max_length=50)
    last = models.CharField(max_length=50)
    events = models.ManyToManyField(Event, blank=True, related_name="participants")

    